create definer = root@localhost trigger insert_new_user
    after insert
    on user
    for each row
    INSERT INTO personal_info(user_id) VALUES(new.user_id);

